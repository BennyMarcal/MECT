package entities;

import SharedRegions.Playground;
import SharedRegions.ContestantsBench;
import SharedRegions.GeneralRepos;
import SharedRegions.RefereeSite;
import States.*;

public class Contestant extends Thread {

    protected final int contestantID;
    protected int contestantStrength; // Changed to non-final
    private int teamID;
    private int selected;
    private int contestantstate;

    protected final ContestantsBench contestantsBench;
    protected final GeneralRepos repos;
    protected final RefereeSite refereeSite;
    protected final Playground playground;

    private boolean matchOverFlag;

    public Contestant(ContestantsBench contestantsBench, int contestantID, int contestantStrength, GeneralRepos repos, RefereeSite refereeSite, Playground playground,GeneralRepos repos1) {
        this.contestantsBench = contestantsBench;
        this.contestantID = contestantID;
        this.contestantStrength = contestantStrength;
        this.playground = playground;
        this.refereeSite = refereeSite;
        this.repos = repos;
        this.contestantstate = Contestantstates.SEAT_AT_THE_BENCH;
    }

    public int getTeamId() {
        return this.teamID;
    }

    public int getContestantID() {
        return this.contestantID;
    }

    public void setContestantStrength(int contestantStrength) {
        this.contestantStrength = contestantStrength;
    }

    public int getContestantStrength() {
        return this.contestantStrength;
    }

    public int getContestantState() {
        return this.contestantstate;
    }

    public void setContestantState(int contestantstate) {
        this.contestantstate = contestantstate;
    }

    public void setMatchOver() {
        this.matchOverFlag = true;
    }

    public int isSelected() {
        return this.selected; // Return the selected value
    }

    public void setSelectState(int selected) {
        this.selected = selected;
    }

    @Override
    public void run() {
        while (true) {
            this.contestantsBench.callContestants(this.contestantID); // Pass contestant ID as argument
            if (matchOverFlag) break;

            this.contestantsBench.followCoachAdvice(this.contestantID); // Pass contestant ID as argument

            this.playground.getREADY(this); // Pass contestant object as argument
            this.playground.pullTheRope(this, this.teamID); // Pass contestant object and teamID as arguments
            this.playground.assertTrialDecision(this.contestantID); // Pass contestant ID as argument
            this.refereeSite.waitForTrialConclusion(); // Pass contestant object as argument

            this.contestantsBench.seatDown(this); // Pass contestant object as argument
        }
    }
}
