package entities;

import States.Coachstates;
import SharedRegions.ContestantsBench;
import SharedRegions.GeneralRepos;
import SharedRegions.Playground;
import SharedRegions.RefereeSite;
import States.Refstates;


public class Coach extends Thread{



    private int coachState;
    private int coachID;
    private int teamID;

    protected final ContestantsBench contestantsBench;

    protected final GeneralRepos repos;

    protected final RefereeSite refereeSite;
    protected final Playground playground;

  
    
    public Coach(int coachID, int teamID, ContestantsBench contestantsBench, RefereeSite refereeSite, Playground playground,GeneralRepos repos) {
        this.coachID = coachID; 
        this.teamID = teamID;
        this.contestantsBench = contestantsBench;
        this.refereeSite = refereeSite;
        this.playground = playground;
        this.coachState=Coachstates.WAIT_FOR_REFEREE_COMMAND;
        this.repos=repos;

    }



    public int getCoachID(){
        return this.coachID;
    }

    public int getCoachState() {
        return this.coachState;
    }


    public void setCoachState(int coachState) {
        this.coachState = coachState;
    }


    @Override
    public void run() {
        boolean matchInProgress = true;
        while (matchInProgress) {
            synchronized (refereeSite) {
                // Wait for the referee to announce the start of the game or trial.
                try {
                    while (refereeSite.getCoachState() != Coachstates.WAIT_FOR_REFEREE_COMMAND) {
                        refereeSite.wait(); // Wait for a change that signals START_OF_A_GAME
                    }
                    System.out.println("Coach is unlocked to call the team: " + this.teamID);
                    synchronized (contestantsBench) { // Correct variable name
                        // Call the contestants to assemble the team
                        contestantsBench.callContestants(this.teamID); // Correct method call
                        while (contestantsBench.getCoachState() != Coachstates.WATCH_TRIAL) { // Correct method call
                            contestantsBench.wait(); // Correct method call
                        }
                    }
                    System.out.println("Informing referee that team " + teamID + " is ready...");

                    synchronized (refereeSite) {
                        refereeSite.informReferee();
                        while (refereeSite.getRefereeState() != Refstates.WAIT_FOR_TRIAL_CONCLUSION) { // Correct enum name
                            refereeSite.wait();
                        }
                        System.out.println("Reviewing notes...");
                        refereeSite.reviewNotes(this, teamID);
                        matchInProgress = refereeSite.getGameState();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Thread.currentThread().interrupt(); // Preserve interruption status.
                    return; // Exit the loop and thread execution.
                }
            }
        }
    }
    }





