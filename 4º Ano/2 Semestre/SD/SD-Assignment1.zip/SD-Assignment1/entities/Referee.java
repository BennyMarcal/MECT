package entities;

import SharedRegions.ContestantsBench;

import States.Refstates;
import SharedRegions.GeneralRepos;
import SharedRegions.RefereeSite;
import SharedRegions.Playground;

public class Referee extends Thread {
    
    protected final GeneralRepos repos;
    protected final RefereeSite refereeSite;
    protected final Playground playground;
    protected final ContestantsBench contestantsBench; // Declare contestantsBench variable

    protected int refereeState;
    private final int refereeID;
    private int numberOfTrialsForTheGame = 0;
    private int ropePosition;

    public Referee(int refereeID, RefereeSite refereeSite, Playground playground, ContestantsBench contestantsBench, GeneralRepos repos) {
        this.refereeID = refereeID;
        this.refereeSite = refereeSite;
        this.playground = playground;
        this.contestantsBench = contestantsBench; // Assign the parameter value to contestantsBench variable
        this.repos = repos;
        this.refereeState = Refstates.START_OF_MATCH;
    }

    public int getRefereeID() {
        return this.refereeID;
    }

    public int getRefereeState() {
        return this.refereeState;
    }

    public void setRopePosition(int ropePosition) {
        this.ropePosition = ropePosition;
    }

    public int getRopePosition() {
        return this.ropePosition;
    }

    public void setRefereeState(int refereeState) {
        this.refereeState = refereeState;
    }

    public void run() {
        int numberOfTrialsForTheGame;
        int numberofgames = 0;
        
        while (numberofgames < 3) {
            this.refereeSite.announceNewGame();
            numberOfTrialsForTheGame = 0;
    
            while (numberOfTrialsForTheGame < 6) {
                this.refereeSite.callTrial();
                this.playground.startTrial();
                numberOfTrialsForTheGame++;
    
                this.refereeSite.callTrial();
            }
    
            this.refereeSite.declareGameWinner();
            numberofgames++;
        }
    
        this.refereeSite.declareMatchWinner(this); // Pass the current Referee object
        this.refereeSite.amDone();
    }
}
