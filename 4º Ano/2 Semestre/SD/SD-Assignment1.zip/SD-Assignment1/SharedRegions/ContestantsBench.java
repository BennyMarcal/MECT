package SharedRegions;

import entities.Coach;
import entities.Contestant;
import States.Coachstates;
import States.Contestantstates;
import Main.SimulPar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ContestantsBench {

    private int coachState;
    private int cntState;
    private final List<Contestant> contestants;
    private final List<Contestant> selectedContestants;
    private int contestantArrived;
    private boolean matchOverFlag;
    private boolean [] contestantChosenForTrial;
    private boolean [] callContestantsFlag;

    public ContestantsBench() {
        this.contestants = new ArrayList<>();
        this.selectedContestants = new ArrayList<>();
        this.coachState = Coachstates.ASSEMBLE_TEAM;
        this.cntState = Contestantstates.SEAT_AT_THE_BENCH;
        this.contestantArrived = 0;
    }

    public synchronized void addContestant(Contestant contestant, int teamID) {
        if (contestant.getTeamId() == teamID) {
            contestants.add(contestant);
        }
    }

    public synchronized void resetBench() {
        for (Contestant contestant : contestants) {
            contestant.setSelectState(0);
        }
    }

    public synchronized void waitForCallContestants(){
        Contestant contestant = (Contestant) Thread.currentThread();
        int ID = contestant.getContestantID();

        
        while ((!this.contestantChosenForTrial[contestant.getContestantID()] || !this.callContestantsFlag[ID / SimulPar.TEAM_SIZE]) && !this.matchOverFlag ) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (this.matchOverFlag) {
            contestant.setMatchOver();
        }

    }
    public synchronized void getTeamId() {
        System.out.println("Team ID: " + contestants.get(0).getTeamId());
    }

    public synchronized void callContestants(int teamId) {
        System.out.println("Assembling the team with ID: " + teamId);
        this.coachState = Coachstates.ASSEMBLE_TEAM;
        contestantArrived = 0;
        notifyAll();
    }

    public synchronized void followCoachAdvice(int contestantID) {
        // Sort contestants by strength
        Collections.sort(contestants, Comparator.comparingInt(Contestant::getContestantStrength).reversed());

        // Track the number of selected contestants
        int countSelected = 0;

        System.out.println("Contestant " + contestantID + " follows coach advice.");
        contestantArrived++;

        // Add the top 3 contestants to the selected contestants list
        for (int i = 0; i < Math.min(3, contestants.size()); i++) {
            Contestant contestant = contestants.get(i);
            if (contestant.isSelected() == 0) {
                selectedContestants.add(contestant);
                contestant.setSelectState(1);
                countSelected++;
                contestant.setContestantState(Contestantstates.STAND_IN_POSITION);
                System.out.println("Contestant " + contestant.getContestantID() + " from team:" + contestant.getTeamId() + " is selected to join the trial.");
                cntState = Contestantstates.STAND_IN_POSITION;
            }
        }

        // If 3 contestants have been selected, notify coaches
        if (countSelected == 3) {
            countSelected = 0;
            coachState = Coachstates.WATCH_TRIAL;
            System.out.println("All contestants are ready to start the trial.");
            notifyAll();
        }
    }

    public synchronized int getCoachState() {
        return coachState;
    }

    public synchronized int getCntState() {
        return cntState;
    }

    public synchronized void seatDown(Contestant contestant) {
        contestant.setContestantState(Contestantstates.SEAT_AT_THE_BENCH);
        System.out.println("Contestant " + contestant.getContestantID() + " went back to the bench.");
        cntState = Contestantstates.SEAT_AT_THE_BENCH;
    }
}
