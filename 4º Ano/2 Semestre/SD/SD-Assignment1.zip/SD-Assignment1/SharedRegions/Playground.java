package SharedRegions;

import entities.Contestant;
import States.Contestantstates;
import SharedRegions.GeneralRepos;
import entities.Coach;
import States.Refstates;

/**
 *   Playground.
 *   In this shared region, contestants will be preparing for competitions and performing their tasks.
 */
public class Playground {

    private final GeneralRepos repos;
    private int CntState;
    private int CoachState;
    private int RefState;
    private int team1Strength;
    private int team2Strength;
    private int team1Ready, team2Ready;
    private int contestantsPulling = 0;
    private int contestantArrived = 0;
    private int strengthDifference;
    private int ropePosition; 
    private int gamesteam1wins = 0;
    private int gamesteam2wins = 0;
    private int numTrials;

    public Playground(GeneralRepos repos) {
        this.repos = repos;
    }

    public synchronized void backToBench(Contestant contestant) {
        System.out.println("Contestant " + contestant.getContestantID() + " was not selected!");
        contestant.setContestantStrength(contestant.getContestantStrength() + 1);
    }

    public synchronized void getREADY(Contestant contestant) {
        if (contestant.isSelected() == 1) {
            if (contestant.getTeamId() == 1) {
                team1Strength += contestant.getContestantStrength();
                team1Ready++;
            } else {
                team2Strength += contestant.getContestantStrength();
                team2Ready++;
            }
            System.out.println("Contestant with ID " + contestant.getContestantID() + " added strength, total now: " + (contestant.getTeamId() == 1 ? team1Strength : team2Strength));
        } else {
            backToBench(contestant);
        }
        contestantArrived++;
        if (team1Ready == 3 && team2Ready == 3 && contestantArrived == 10) {
            team1Ready = 0;
            team2Ready = 0;
            contestantArrived = 0;
            CntState = Contestantstates.DO_YOUR_BEST;
            System.out.println("Pulling the rope...");
            notifyAll();
        }
    }

    public synchronized int assertTrialDecision(int numTrials) {
        if (numTrials < 6) {
            if (ropePosition > 0 && ropePosition <= 3) {
                System.out.println("Team 1 is winning, game still going with rope position " + ropePosition);
                RefState = Refstates.START_OF_MATCH;
                notifyAll();
                return ropePosition;
            } else if (ropePosition < 0 && ropePosition >= -3) {
                System.out.println("Team 2 is winning, game still going with rope position " + ropePosition);
                RefState = Refstates.START_OF_MATCH;
                notifyAll();
                return ropePosition;
            } else if (ropePosition == 0) {
                System.out.println("Game is at a draw, game still going with rope position " + ropePosition);
                RefState = Refstates.START_OF_MATCH;
                notifyAll();
                return ropePosition;
            } else if (ropePosition > 3) {
                System.out.println("Team 1 wins by knockout with rope position " + ropePosition);
                gamesteam1wins++;
                RefState = Refstates.END_OF_GAME;
                notifyAll();
                return ropePosition;
            } else if (ropePosition < -3) {
                System.out.println("Team 2 wins by knockout with rope position " + ropePosition);
                gamesteam2wins++;
                RefState = Refstates.END_OF_GAME;
                notifyAll();
                return ropePosition;
            }
        } else {
            if (ropePosition > 0) {
                System.out.println("Team 1 wins the game! Rope position: " + ropePosition);
                gamesteam1wins++;
                RefState = Refstates.END_OF_GAME;
                notifyAll();
                return ropePosition;
            } else if (ropePosition < 0) {
                System.out.println("Team 2 wins the game! Rope position: " + ropePosition);
                gamesteam2wins++;
                RefState = Refstates.END_OF_GAME;
                notifyAll();
                return ropePosition;
            } else {
                System.out.println("Game is a draw! Rope position: " + ropePosition);
                RefState = Refstates.END_OF_GAME;
                notifyAll();
                return ropePosition;
            }
        }
        return -1;
    }

    public synchronized void pullTheRope(Contestant contestant, int strength) {
        System.out.println("Contestant " + contestant.getContestantID() + " is pulling the rope with strength " + strength);
        contestantsPulling++;
        if (contestantsPulling == 6) {
            strengthDifference = Math.abs(team1Strength - team2Strength);
            if (team1Strength > team2Strength) {
                if (strengthDifference < 3) {
                    ropePosition += 1;
                    System.out.println("Rope moved towards Team 1 by 1 unit.");
                } else {
                    ropePosition += 2;
                    System.out.println("Rope moved towards Team 1 by 2 units.");
                }
            } else if (team2Strength > team1Strength) {
                if (strengthDifference < 3) {
                    ropePosition -= 1;
                    System.out.println("Rope moved towards Team 2 by 1 unit.");
                } else {
                    ropePosition -= 2;
                    System.out.println("Rope moved towards Team 2 by 2 units.");
                }
            } else {
                System.out.println("Rope did not move.");
            }
            contestantsPulling = 0;
            RefState = Refstates.WAIT_FOR_TRIAL_CONCLUSION;
            CntState = Contestantstates.SEAT_AT_THE_BENCH;
            notifyAll();
        }
    }

    public synchronized void startTrial() {
        team1Strength = 0;
        team2Strength = 0;
        System.out.println("Referee started trial");
        CntState = Contestantstates.STAND_IN_POSITION;
        notifyAll();
    }

    public synchronized int getCntState() {
        return CntState;
    }

    public synchronized int getCoachState() {
        return CoachState;
    }

    public synchronized int getRefState() {
        return RefState;
    }

    public synchronized void setRopePosition(int ropePosition) {
        this.ropePosition = ropePosition;
    }
}