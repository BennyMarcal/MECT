package SharedRegions;

import entities.*;
import Main.SimulPar;
import States.*;
import SharedRegions.*;
import java.io.*;
import java.util.*;

public class GeneralRepos {

    private final String logFileName;

    private int[] contestantStates;
    private int[] contestantStrengths;
    private int[] coachStates;
    private int RefState;
    private int numberofgames;
    private int numberOfTrialsForTheGame;
    private int mark;
    private int[][] participatingContestants;

    public GeneralRepos(String logFileName, int numberOfContestants) {
        if (logFileName == null || logFileName.equals(""))
            this.logFileName = "logger";
        else
            this.logFileName = logFileName;

        contestantStates = new int[numberOfContestants];
        contestantStrengths = new int[numberOfContestants];
        for (int i = 0; i < numberOfContestants; i++) {
            contestantStates[i] = Contestantstates.RETURN_TO_BENCH;
            contestantStrengths[i] = 0; // Initialize strength to 0, you may set it differently if required
        }

        coachStates = new int[SimulPar.NUM_TEAMS];
        for (int i = 0; i < SimulPar.NUM_TEAMS; i++) {
            coachStates[i] = Coachstates.WAIT_FOR_REFEREE_COMMAND;
        }

        participatingContestants = new int[SimulPar.NUM_TEAMS][SimulPar.NUMBER_OF_CONTESTANTS_PER_TRIAL];
        for (int i = 0; i < SimulPar.NUM_TEAMS; i++) {
            for (int j = 0; j < SimulPar.NUMBER_OF_CONTESTANTS_PER_TRIAL; j++) {
                participatingContestants[i][j] = -1;
            }
        }

        printTitle();
        printHeader();
    }


    public synchronized void setContestantState(int id, int state) {
        contestantStates[id] = state;
        printState();
    }

    public synchronized void setParticipatingContestants(int id, int[] participatingContestants) {
        this.participatingContestants[id] = participatingContestants;
    }

    public synchronized void setCoachState(int id, int state) {
        coachStates[id] = state;
        printState();
    }

    public synchronized void setRefereeState(int state) {
        this.RefState = state;
        if (state == Refstates.START_OF_MATCH) {
            numberofgames++;
            numberOfTrialsForTheGame = 0;
            mark = 0;
            printGame();
            printHeader();
        }

        if (state == Refstates.WAIT_FOR_TRIAL_CONCLUSION) {
            numberOfTrialsForTheGame++;
        }
        printState();
    }

    public synchronized void setMark(int mark) {
        this.mark = mark;
    }

    public synchronized void updateContestantsStrength(int id, int[] contestantsStrength) {
        for (int i = id * SimulPar.TEAM_SIZE; i < (id + 1) * SimulPar.TEAM_SIZE; i++) {
            contestantStrengths[i] = contestantsStrength[i % SimulPar.TEAM_SIZE];
        }
    }

    public synchronized void declareGameWinner(int id) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFileName, true))) {
            if (numberOfTrialsForTheGame == SimulPar.MAX_TRIALS) {
                writer.println(String.format("Game %d was won by team %d by points.", numberofgames, id + 1));
            } else {
                writer.println(String.format("Game %d was won by team %d by knockout in %d trials.", numberofgames, id + 1, numberOfTrialsForTheGame));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void declareGameDraw() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFileName, true))) {
            writer.println(String.format("Game %d was a draw.", numberofgames));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void declareMatchWinner(int id, int pointsTeam1, int pointsTeam2) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFileName, true))) {
            writer.println(String.format("Match was won by team %d (%d - %d).", id + 1, pointsTeam1, pointsTeam2));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void declareMatchDraw(int pointsTeam1, int pointsTeam2) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFileName, true))) {
            writer.println(String.format("Match was a draw (%d - %d).", pointsTeam1, pointsTeam2));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void printTitle() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFileName, true))) {
            writer.println("                            Game of the Rope - Description of the internal state\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void printHeader() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFileName, true))) {
            writer.println("Ref Coa 1 Cont 1 Cont 2 Cont 3 Cont 4 Cont 5 Coa 2 Cont 1 Cont 2 Cont 3 Cont 4 Cont 5         Trial       ");
            writer.println("Sta  Stat Sta SG Sta SG Sta SG Sta SG Sta SG  Stat Sta SG Sta SG Sta SG Sta SG Sta SG   3 2 1 . 1 2 3 NB PS");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void printGame() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFileName, true))) {
            writer.println("Game " + numberofgames);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void printState() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(logFileName, true))) {
            String states = String.format("%3d  %4d %3d %2d %3d %2d %3d %2d %3d %2d %3d %2d  %4d %3d %2d %3d %2d %3d %2d %3d %2d %3d %2d",
                    RefState,
                    coachStates[0],
                    contestantStates[0], contestantStrengths[0],
                    contestantStates[1], contestantStrengths[1],
                    contestantStates[2], contestantStrengths[2],
                    contestantStates[3], contestantStrengths[3],
                    contestantStates[4], contestantStrengths[4],
                    coachStates[1],
                    contestantStates[5], contestantStrengths[5],
                    contestantStates[6], contestantStrengths[6],
                    contestantStates[7], contestantStrengths[7],
                    contestantStates[8], contestantStrengths[8],
                    contestantStates[9], contestantStrengths[9]
            );

            StringBuilder trialStatus = new StringBuilder();
            for (int teamID = 0; teamID < SimulPar.NUM_TEAMS; teamID++) {
                for (int i = 0; i < SimulPar.NUMBER_OF_CONTESTANTS_PER_TRIAL; i++) {
                    int idToAppend = participatingContestants[teamID][i];
                    if (idToAppend != -1) {
                        trialStatus.append(String.format("%d ", idToAppend));
                    } else {
                        trialStatus.append("- ");
                    }
                }
                if (teamID == 0) trialStatus.append(". ");
            }

            if (numberOfTrialsForTheGame > 0) {
                trialStatus.append(String.format("%d ", numberOfTrialsForTheGame));
                trialStatus.append(mark);
            }

            writer.println(states + "   " + trialStatus);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}