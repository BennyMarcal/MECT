package SharedRegions;
import States.Refstates;
import entities.Coach;
import entities.Contestant;
import entities.Referee;
import States.Coachstates;
import SharedRegions.*;

public class RefereeSite {

    

    private int refereeState;
    private boolean trialConcluded;
    private int teamsReadyCount;
    private int CoachState;
    private int RefState;
    private int state;
    private boolean gameState;
    private int numGames;
    private int notesreviewed=0;
    private int finishedGames;

    private int gamesteam1wins, gamesteam2wins;
    


    public RefereeSite() {
        this.state = Refstates.START_OF_MATCH;
    }

    public synchronized void setRefereeState(int state) {
        refereeState = state;
    }

    public synchronized int getRefereeState() {
        return refereeState;
    }

    public int getState() {
        return state;
    }
    public synchronized boolean getGameState() {
        return gameState;
    }

    public synchronized void setTrialConcluded(boolean concluded) {
        trialConcluded = concluded;
    }

    public synchronized boolean isTrialConcluded() {
        return trialConcluded;
    }

    public synchronized void announceNewGame() {
        // Logic to announce a new game
        refereeState=Refstates.START_OF_MATCH;
        System.out.println("Referee announces the start of the match.");
        notifyAll();
       
    }
    public synchronized void informReferee() {
        teamsReadyCount++;
        System.out.println("Number of teams ready: "+ teamsReadyCount+ ", Referee informed");
        if (teamsReadyCount == 2) {
            RefState = Refstates.TEAMS_ARE_READY;
            System.out.println("Both teams are ready");
            teamsReadyCount = 0;
            CoachState = Coachstates.WATCH_TRIAL;
            //repos.setCoachState(Coach.getCoachID(), CoachState);
            notifyAll();
        }
       
    }
    public synchronized void reviewNotes(Coach coach ,int teamID) {
        notesreviewed++;
        System.out.println("Coach from team: "+teamID+" reviewed notes");
        // coach.setCoachState(CoachStates.Wait_For_Referee_Command);
        // repos.setCoachState(coach.getCoachID(), CoachStates.Wait_For_Referee_Command);        
        if (notesreviewed == 2) {
            notesreviewed = 0;
            RefState = Refstates.WAIT_FOR_TRIAL_CONCLUSION;
            notifyAll();
        }
    }

    public synchronized void callTrial() {
        CoachState = Coachstates.WAIT_FOR_REFEREE_COMMAND;
        //repos.setCoachState(coach.getCoachID(), CoachStates.Wait_For_Referee_Command);
        //referee.setRefereeState(RefereeStates.TEAMS_READY);
        System.out.println("Referee calling trial...");
        notifyAll();
    }
 
    public synchronized void endGame(){
        System.out.println("Game ended , referee is checking the results...");
        RefState = Refstates.WAIT_FOR_TRIAL_CONCLUSION;
        //repos.setRefState(RefState);
        notifyAll();
    }

    public synchronized void declareGameWinner() {
       
        if (gamesteam1wins == gamesteam2wins) {
            System.out.println("Match is a draw");
        }
        else if (gamesteam1wins > gamesteam2wins) {
            System.out.println("Match winner is team 1");
        
        
        }
         else if (gamesteam1wins< gamesteam2wins) {
            System.out.println("Match winner is team 2");
        } 
        gameState = false;
        System.out.println("Referee declared the match winner");    
    }
    public synchronized void declareMatchWinner(Referee referee) {
        String winnerMessage = "";
        if (referee.getRopePosition() > 0) {
            winnerMessage = "Game winner is team 1";
            gamesteam1wins++;
        } else if (referee.getRopePosition() < 0) {
            winnerMessage = "Game winner is team 2";
            gamesteam2wins++;
        } else {
            winnerMessage = "Game is a draw";
            numGames++;
        }
    
        System.out.println(winnerMessage);
        System.out.println("Referee declared the game winner");
    
        finishedGames = gamesteam1wins+ gamesteam2wins + numGames;
        if (finishedGames == 3) {
            System.out.println("Match is over");
            RefState = Refstates.END_OF_MATCH;
        } else {
            System.out.println("Match is not over yet, another game will be played");
            RefState = Refstates.START_OF_MATCH;
        }
        
        notifyAll();
    }
    
        // Method for ending game
        public synchronized void amDone() {
            System.out.println("Game ended , referee is checking the results...");
            RefState = Refstates.WAIT_FOR_TRIAL_CONCLUSION;
            //repos.setRefState(RefState);
            notifyAll();
        }

        // Method for the referee to wait for the trial conclusion
        public synchronized void waitForTrialConclusion() {
            while (!isTrialConcluded()) {
                try {
                    wait(); // Wait until a contestant informs the referee
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Thread.currentThread().interrupt();
                }
            }
            setRefereeState(Refstates.ASSERT_TRIAL_DECISION);
            System.out.println("Trial concluded.");
            notifyAll(); // Notify any waiting threads (e.g., coach) about the trial conclusion
        }
     /**
     * get the state of the coach
     * @return the state of the coach
     */
    public synchronized int getCoachState() {
        return CoachState;
    }


}


