package States;


public class Contestantstates {
    
    
    // Define states using constants
    public static final int SEAT_AT_THE_BENCH = 0;
    public static final int STAND_IN_POSITION = 1;
    public static final int DO_YOUR_BEST = 2;
    public static final int STAND_BY = 3; // Added constant
    public static final int COMPETE = 4; // Added constant
    public static final int RETURN_TO_BENCH = 5; // Added constant
    
    private Contestantstates() {

    }
}