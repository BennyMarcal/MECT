package States;


public class Refstates {
    

    // Define states using constants
    public static final int START_OF_MATCH = 0;
    public static final int TEAMS_READY = 1;
    public static final int WAIT_FOR_TRIAL_CONCLUSION = 2;
    public static final int ASSERT_TRIAL_DECISION = 3;
    public static final int END_OF_MATCH = 4;
    public static final int END_OF_GAME = 5;
    public static final int ANNOUNCE_TRIAL = 1;
    public static final int TEAMS_ARE_READY = 1;

    private Refstates() {
        
    }
}