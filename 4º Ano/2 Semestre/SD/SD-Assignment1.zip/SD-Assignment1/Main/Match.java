package Main;

import entities.*;
import SharedRegions.*;
import Main.*;

public class Match {
    public static void main(String[] args) {
        // Initialize shared regions
        GeneralRepos generalRepos = new GeneralRepos("logger", 1); // Change the second argument to an int
        Playground playground = new Playground(generalRepos);
        RefereeSite refereeSite = new RefereeSite();
        ContestantsBench contestantsBench1 = new ContestantsBench();
        ContestantsBench contestantsBench2 = new ContestantsBench();

        // Create referee, coaches, and contestants
        Referee referee = new Referee(1, refereeSite, playground, contestantsBench1, generalRepos);
        Coach coach1 = new Coach(1, 1, contestantsBench1, refereeSite, playground, generalRepos);
        Coach coach2 = new Coach(2, 2, contestantsBench2, refereeSite, playground, generalRepos);

        Contestant[] team1 = new Contestant[5];
        Contestant[] team2 = new Contestant[5];

        // Start contestants for each team
        for (int i = 0; i < 5; i++) {
            team1[i] = new Contestant(contestantsBench1, i, 1, generalRepos, refereeSite, playground, generalRepos);
            team1[i].start();

            team2[i] = new Contestant(contestantsBench2, i, 2, generalRepos, refereeSite, playground, generalRepos);
            team2[i].start();
        }

        // Start referee and coaches
        referee.start();
        coach1.start();
        coach2.start();

        // Wait for all contestants to finish
        for (int i = 0; i < 5; i++) {
            try {
                team1[i].join();
                team2[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Wait for referee and coaches to finish
        try {
            referee.join();
            coach1.join();
            coach2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
