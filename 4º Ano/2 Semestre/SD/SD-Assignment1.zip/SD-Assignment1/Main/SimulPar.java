package Main;

/**
 * Definition of the simulation parameters.
 */
public final class SimulPar {
    // Number of teams in the game
    public static final int NUM_TEAMS = 2;

    // Number of contestants in each team
    public static final int TEAM_SIZE = 5;

    // Number of games in a match
    public static final int NUM_GAMES = 3;
    public static final int NUMBER_OF_SELECTED_CONTESTANTS = 3;

    // Maximum number of trials in a game
    public static final int MAX_TRIALS = 6;

    // Threshold for a knockout victory
    public static final int KNOCKOUT_THRESHOLD = 4;

    // Number of units of strength gained or lost per action
    public static final int STRENGTH_CHANGE = 1;

    // Maximum time interval for contestants to sleep
    public static final int MAX_SLEEP_INTERVAL = 1000; // milliseconds

    public static final int NUMBER_OF_CONTESTANTS_PER_TRIAL = NUMBER_OF_SELECTED_CONTESTANTS * NUM_TEAMS;
    // It cannot be instantiated
    private SimulPar() {
    }
}
