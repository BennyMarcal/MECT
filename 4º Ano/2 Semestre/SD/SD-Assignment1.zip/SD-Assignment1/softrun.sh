print_separator() {
    echo "*************************************************************"
    echo "************************** ROPE GAME ************************"
    echo "*************************************************************"
}

# compile entities
echo "Compiling entities..."
javac entities/Referee.java
javac entities/Contestant.java
javac entities/Coach.java

# compile SharedRegions
echo "Compiling SharedRegions..."
javac SharedRegions/Playground.java
javac SharedRegions/RefereeSite.java
javac SharedRegions/ContestantsBench.java
javac SharedRegions/GeneralRepos.java


# compile Main
echo "Compiling Main..."
javac Main/Match.java

# Run the program
echo "Running Match..."
print_separator
java Main/Match