#!/bin/bash

# Function to compile Java files
compile() {
    echo "Compiling $1..."
    if ! javac "$1"; then
        echo "Error: Compilation failed for $1"
        exit 1
    fi
}

# Function to clean .class files
clean() {
    echo "Cleaning .class files in $1..."
    rm -f "$1"/*.class
}

# Function to print a separator
print_separator() {
    echo "*************************************************************"
    echo "************************** ROPE GAME ************************"
    echo "*************************************************************"
}

# Clean entities
clean entities

# Clean SharedRegions
clean SharedRegions

# Clean Main
clean Main

clean Utils

# Compile entities
echo "Compiling entities..."
compile entities/Referee.java
compile entities/Contestant.java
compile entities/Coach.java

# Compile SharedRegions
echo "Compiling SharedRegions..."
compile SharedRegions/Playground.java
compile SharedRegions/RefereeSite.java
compile SharedRegions/ContestantsBench.java
compile SharedRegions/GeneralRepos.java


# Compile Main
echo "Compiling Main..."
compile Main/Match.java

# Run the program
echo "Running Match..."
print_separator
java Main/Match

