clean() {
    echo "Cleaning .class files in $1..."
    rm -f "$1"/*.class
}

# Function to print a separator
print_separator() {
    echo "*************************************************************"
    echo "********************* CLEANING .CLASS ***********************"
    echo "*************************************************************"
}

# Clean entities
clean entities

# Clean SharedRegions
clean SharedRegions

# Clean Main
clean Main

clean Utils