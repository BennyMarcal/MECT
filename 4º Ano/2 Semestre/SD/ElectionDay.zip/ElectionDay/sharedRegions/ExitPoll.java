package sharedRegions;

import java.util.Random;
import utils.Logger;

public class ExitPoll {
    private final Random rand = new Random();
    private final Logger logger;

    public ExitPoll(Logger logger) {
        this.logger = logger;
    }

    public void inquireVoter(int voterID) throws InterruptedException {
        if (rand.nextDouble() < 0.10) {  
            Thread.sleep(rand.nextInt(6) + 5);  
            boolean truthful = rand.nextDouble() < 0.80;
            logger.log("📊 Pollster perguntou ao voter " + voterID + (truthful ? " (🗣️ Verdadeiro)" : " (🤥 Mentiroso)"));
        }
    }
}
