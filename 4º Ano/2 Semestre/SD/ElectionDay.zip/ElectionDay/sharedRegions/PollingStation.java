package sharedRegions;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import utils.Logger;

public class PollingStation {
    private final int maxCapacity;
    private final int queueSize;
    private int currentVoters = 0;
    private boolean isOpen = true;
    private final Queue<Integer> waitingQueue = new LinkedList<>();
    private final HashSet<Integer> usedIDs = new HashSet<>();
    private final Random rand = new Random();
    private final Logger logger;

    public PollingStation(int maxCapacity, int queueSize, Logger logger) {
        this.maxCapacity = maxCapacity;
        this.queueSize = queueSize;
        this.logger = logger;
    }

    // Entrar na estação (respeita a ordem e limite da fila)
    public synchronized void enterStation(int voterID) throws InterruptedException {
        while (currentVoters >= maxCapacity || waitingQueue.size() >= queueSize) {
            wait();  // Espera até haver espaço na estação ou na fila
        }
        waitingQueue.add(voterID);
        logger.log("🟢 Voter " + voterID + " entrou na fila.");
        notifyAll();
    }

    // Validar ID e garantir ordem de entrada
    public synchronized void validateVoter(int voterID) throws InterruptedException {
        while (waitingQueue.peek() != voterID) {
            wait();  // Garante que a ordem é respeitada
        }
        waitingQueue.poll();  // Remove da fila
        Thread.sleep(rand.nextInt(6) + 5);  // Simula tempo de validação (5-10ms)
        
        if (usedIDs.contains(voterID)) {
            logger.log("❌ Voter " + voterID + " tentou votar novamente! Expulso.");
            return;
        }
        
        usedIDs.add(voterID);
        currentVoters++;
        logger.log("✅ Voter " + voterID + " validado.");
        notifyAll();
    }

    // Sair da estação e liberar espaço para outros votantes
    public synchronized void exitStation(int voterID) {
        currentVoters--;
        logger.log("🚪 Voter " + voterID + " saiu da estação.");
        notifyAll();
    }

    // Gerir a fila de espera
    public synchronized void manageQueue() {
        notifyAll();  // Notifica votantes que podem entrar
    }

    // Retorna o próximo votante na fila
    public synchronized int getNextVoter() {
        return waitingQueue.isEmpty() ? -1 : waitingQueue.peek();
    }

    // Fecha a estação de votação
    public synchronized void closePolling() {
        isOpen = false;
        notifyAll();
    }

    public boolean isPollingOpen() {
        return isOpen;
    }
}
