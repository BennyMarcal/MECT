package sharedRegions;

import java.util.Random;
import utils.Logger;

public class EVotingBooth {
    private final Random rand = new Random();
    private final Logger logger;

    public EVotingBooth(Logger logger) {
        this.logger = logger;
    }

    public void castVote(int voterID) throws InterruptedException {
        Thread.sleep(rand.nextInt(16));  
        logger.log("🗳️ Voter " + voterID + " votou.");
    }
}
