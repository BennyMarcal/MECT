package main;

import entities.*;
import sharedRegions.*;
import utils.Logger;

public class ElectionDaySimulation {
    public static void main(String[] args) {
        int numVoters = 5;  
        int stationCapacity = 3;
        int queueSize = 2;

        Logger logger = new Logger();
        PollingStation pollingStation = new PollingStation(stationCapacity, queueSize, logger);
        EVotingBooth eVotingBooth = new EVotingBooth(logger);
        ExitPoll exitPoll = new ExitPoll(logger);

        PollClerk pollClerk = new PollClerk(pollingStation, eVotingBooth, logger);
        Pollster pollster = new Pollster(exitPoll, logger);

        Voter[] voters = new Voter[numVoters];
        for (int i = 0; i < numVoters; i++) {
            voters[i] = new Voter(i, pollingStation, eVotingBooth, exitPoll, pollster, logger);
            voters[i].start();
        }

        pollClerk.start();

        try {
            for (Voter voter : voters) {
                voter.join();
            }
            pollClerk.interrupt();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        pollingStation.closePolling();
        logger.saveLog();
        System.out.println("🏁 Eleições encerradas.");
    }
}
