package entities;

import sharedRegions.*;
import utils.Logger;

public class Voter extends Thread {
    private final int id;
    private final PollingStation station;
    private final EVotingBooth booth;
    private final ExitPoll exitPoll;
    private final Pollster pollster;
    private final Logger logger;
    private VoterStates state;

    public Voter(int id, PollingStation station, EVotingBooth booth, ExitPoll exitPoll, Pollster pollster, Logger logger) {
        this.id = id;
        this.station = station;
        this.booth = booth;
        this.exitPoll = exitPoll;
        this.pollster = pollster;
        this.logger = logger;
        this.state = VoterStates.ARRIVING;
    }

    @Override
    public void run() {
        try {
            logger.log("👤 Voter " + id + " chegou ao local de votação.");
            setState(VoterStates.WAITING_QUEUE);
            station.enterStation(id);

            setState(VoterStates.VALIDATING_ID);
            station.validateVoter(id);

            setState(VoterStates.VOTING);
            booth.castVote(id);

            setState(VoterStates.EXITING);
            station.exitStation(id);

            setState(VoterStates.POLLED);
            exitPoll.inquireVoter(id);
            pollster.askVoter(id);

            setState(VoterStates.FINISHED);
            logger.log("✔️ Voter " + id + " completou o processo de votação.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void setState(VoterStates newState) {
        this.state = newState;
        logger.log("🔄 Voter " + id + " mudou para estado: " + state);
    }
}
