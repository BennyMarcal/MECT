package entities;

public enum PollsterStates {
    WAITING,  // Aguardando um votante sair
    QUESTIONING  // Fazendo perguntas ao votante
}
