package entities;

public enum PollClerkStates {
    WAITING_VOTER,   // Aguardando um novo votante
    VALIDATING_ID,   // Está a validar um ID de votante
    MANAGING_QUEUE,  // Gerindo a fila e coordenando entradas
    CLOSING_STATION  // A encerrar a estação de votação
}
