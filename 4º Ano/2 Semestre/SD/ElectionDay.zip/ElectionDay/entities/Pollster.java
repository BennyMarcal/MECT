package entities;

import sharedRegions.ExitPoll;
import utils.Logger;
import java.util.Random;

public class Pollster extends Thread {
    private final ExitPoll exitPoll;
    private final Logger logger;
    private final Random rand = new Random();
    private PollsterStates state;

    public Pollster(ExitPoll exitPoll, Logger logger) {
        this.exitPoll = exitPoll;
        this.logger = logger;
        this.state = PollsterStates.WAITING;
    }

    public void askVoter(int voterID) throws InterruptedException {
        if (rand.nextDouble() < 0.10) {  // 10% de chance de ser abordado
            this.state = PollsterStates.QUESTIONING;
            Thread.sleep(rand.nextInt(6) + 5); // Tempo de resposta (5-10ms)
            
            boolean willAnswer = rand.nextDouble() < 0.60; // 60% dos abordados respondem
            boolean truthful = rand.nextDouble() < 0.80; // 80% dizem a verdade

            if (willAnswer) {
                logger.log("📊 Pollster perguntou ao voter " + voterID +
                        (truthful ? " (🗣️ Disse a verdade)" : " (🤥 Mentiu)"));
            } else {
                logger.log("📊 Pollster perguntou ao voter " + voterID + " (🤐 Recusou responder)");
            }

            this.state = PollsterStates.WAITING;
        }
    }
}
