package entities;

import sharedRegions.PollingStation;
import utils.Logger;

public class PollClerk extends Thread {
    private final PollingStation station;
    private final Logger logger;
    private PollClerkStates state;

    public PollClerk(PollingStation station, Logger logger) {
        this.station = station;
        this.logger = logger;
        this.state = PollClerkStates.WAITING_VOTER;
    }

    @Override
    public void run() {
        try {
            while (station.isPollingOpen()) {
                setState(PollClerkStates.MANAGING_QUEUE);
                station.manageQueue();

                setState(PollClerkStates.WAITING_VOTER);
                int nextVoterID = station.getNextVoter();

                if (nextVoterID != -1) {
                    setState(PollClerkStates.VALIDATING_ID);
                    station.validateVoter(nextVoterID);
                }
                
                Thread.sleep(50);
            }

            setState(PollClerkStates.CLOSING_STATION);
            station.closePolling();
            logger.log("📢 Poll Clerk encerrou a votação.");

        } catch (InterruptedException e) {
            logger.log("⚠️ Poll Clerk interrompido inesperadamente.");
        }
    }

    private void setState(PollClerkStates newState) {
        this.state = newState;
        logger.log("🔄 Poll Clerk mudou para estado: " + state);
    }
}
