package entities;

public enum VoterStates {
    ARRIVING,       // O votante chega à estação
    WAITING_QUEUE,  // Está na fila de espera
    VALIDATING_ID,  // ID está a ser verificado pelo Poll Clerk
    VOTING,         // Está a votar no e-voting booth
    EXITING,        // Está a sair da estação
    POLLED,         // Foi abordado pelo Pollster
    FINISHED        // Completou o processo
}
